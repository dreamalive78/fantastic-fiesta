# NaijaStack - Deployment Guide (No Installation Needed)

Your buyer can deploy in 2 minutes without you. Vercel is primary, but if it fails, use these 1-click alternatives.

## Primary: Vercel (Recommended)
This project is Vercel Ready - Next.js 14 + Tailwind.

1. Push code to GitHub private repo
2. Go to vercel.com > New Project > Import repo
3. Add env vars from `.env.example` in Vercel Dashboard > Settings > Environment Variables
4. Click Deploy

Live URL: `https://your-name.vercel.app/checkout`

If build fails: Check Vercel logs. 90% of fails = missing env vars.

## If Vercel Fails - Option 1: Netlify (1-Click)
1. Go to app.netlify.com > Add new site > Import from Git
2. Select repo
3. Build command: `npm run build`
4. Publish directory: `.next` (leave default)
5. Add env vars from `.env.example` in Site Settings > Environment variables
6. Deploy

Netlify is free and works exactly like Vercel for this kit.

## If Vercel Fails - Option 2: Cloudflare Pages (Fastest in Africa)
Best for your 7 countries - Ghana, Kenya, Uganda, Zambia, Rwanda, Tanzania, Nigeria. Loads fastest on MTN, Airtel, Glo.

1. Go to dash.cloudflare.com > Pages > Create a project > Connect to Git
2. Select repo
3. Framework preset: Next.js
4. Build command: `npm run build`
5. Add env vars from `.env.example`
6. Deploy

Result: `https://naijastack.pages.dev/checkout`

## If Client Insists on Nigerian cPanel (SmartWeb, HostNowNow, WhoGoHost, QServers)

No Node.js needed - use static export.

Run this locally:
```bash
BUILD_MODE=export npm run build
```

This creates an `out/` folder with plain HTML/CSS/JS.

1. Zip the `out` folder
2. Upload to cPanel > File Manager > public_html/checkout
3. Extract

No `npm install` on server. Works on any cheap hosting.

## What to tell your Selar buyers

Add this to your Selar page:

> **Deploy yourself in 2 mins - No installation service:**
> Vercel Ready. If Vercel fails, use Netlify or Cloudflare Pages (1-click). For cPanel, use static export `out/` folder. Full guide in DEPLOYMENT.md.

This protects your ₦225,000 / $149 Pro and $399 Agency price. You are selling source + guide, not installation service.

## Support Checklist for you (seller)

- Keep demo live: https://naijastack.vercel.app/checkout
- Keep private GitHub repo ready for transfer
- Keep WhatsApp support for env setup only, not hosting setup

Built for Selar.co sellers. Ready today.
