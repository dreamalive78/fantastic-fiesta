'use client';
import { useState } from 'react';
import Link from 'next/link';
import { NIGERIAN_BANKS } from '@/lib/ussd/paystack-ussd';
import { MOBILE_MONEY } from '@/lib/ussd/mobile-money';
const TABS = ['All','Nigeria','Ghana','Kenya','Uganda','Zambia','Rwanda','Tanzania'] as const;
export default function BuyPage() {
  const [tab, setTab] = useState<typeof TABS[number]>('All');
  const filteredLogos = (() => {
    if (tab === 'All') return [...NIGERIAN_BANKS.slice(0,8), ...MOBILE_MONEY.slice(0,8)];
    if (tab === 'Nigeria') return NIGERIAN_BANKS;
    if (tab === 'Ghana') return MOBILE_MONEY.filter(m => m.country === 'GH');
    if (tab === 'Kenya') return MOBILE_MONEY.filter(m => m.country === 'KE');
    if (tab === 'Uganda') return MOBILE_MONEY.filter(m => m.country === 'UG');
    if (tab === 'Zambia') return MOBILE_MONEY.filter(m => m.country === 'ZM');
    if (tab === 'Rwanda') return MOBILE_MONEY.filter(m => m.country === 'RW');
    if (tab === 'Tanzania') return MOBILE_MONEY.filter(m => m.country === 'TZ');
    return [];
  })();
  return (
    <div className="min-h-screen bg-white">
      <div className="max-w-6xl mx-auto p-6">
        <div className="text-center py-16">
          <h1 className="text-5xl font-black">NaijaStack USSD + Mobile Money Kit</h1>
          <p className="text-gray-600 mt-4">30 Methods • 7 Countries • Trademark Safe • Vercel Ready</p>
          <div className="flex gap-3 justify-center mt-8">
            <Link href="/checkout" className="bg-black text-white px-8 py-4 rounded-xl">View Live Demo</Link>
            <a href="#pricing" className="border px-8 py-4 rounded-xl">See Pricing</a>
          </div>
        </div>
        <div className="bg-gray-50 rounded-3xl p-6 border">
          <div className="flex flex-wrap gap-2 justify-center mb-6">
            {TABS.map(t => (<button key={t} onClick={() => setTab(t)} className={`px-4 py-2 rounded-full text-sm ${tab===t ? 'bg-black text-white' : 'bg-white border'}`}>{t}</button>))}
          </div>
          <div className="flex flex-wrap gap-4 justify-center">
            {filteredLogos.map(m => (<div key={m.id} className="flex flex-col items-center"><div className="w-12 h-12 rounded-full flex items-center justify-center text-white font-bold text-xs" style={{backgroundColor: m.color}}>{m.initials}</div></div>))}
          </div>
        </div>
        <div id="pricing" className="grid md:grid-cols-3 gap-6 mt-16">
          <div className="border p-8 rounded-3xl"><h3 className="font-bold">Starter</h3><div className="text-4xl font-black mt-2">$49</div></div>
          <div className="bg-black text-white p-8 rounded-3xl"><h3 className="font-bold">Pro - Most Popular</h3><div className="text-4xl font-black mt-2">$149</div><div>₦250,000</div></div>
          <div className="border p-8 rounded-3xl"><h3 className="font-bold">Agency</h3><div className="text-4xl font-black mt-2">$399</div></div>
        </div>
      </div>
    </div>
  );
}
