'use client';
import { useState, useMemo } from 'react';
import { NIGERIAN_BANKS, generatePaystackUSSD } from '@/lib/ussd/paystack-ussd';
import { MOBILE_MONEY, generateMoMoUSSD } from '@/lib/ussd/mobile-money';

export default function CheckoutPage() {
  const [amount, setAmount] = useState(5000);
  const [selectedId, setSelectedId] = useState('gtb');
  const [search, setSearch] = useState('');
  const [currency, setCurrency] = useState('NGN');
  const allMethods = useMemo(() => [...NIGERIAN_BANKS, ...MOBILE_MONEY], []);
  const filtered = useMemo(() => allMethods.filter(m => m.name.toLowerCase().includes(search.toLowerCase())), [allMethods, search]);
  const selected = allMethods.find(m => m.id === selectedId) || NIGERIAN_BANKS[0];
  const isBank = (selected as any).country === 'NG';
  const ussd = isBank ? generatePaystackUSSD(selected as any, amount) : generateMoMoUSSD(selected as any, amount);
  const quickAmounts = [1000, 2000, 5000, 10000, 20000, 50000];
  return (
    <div className="min-h-screen bg-white text-black">
      <div className="max-w-6xl mx-auto p-4 md:p-8">
        <h1 className="text-3xl font-bold mb-2">NaijaStack Checkout 🇳🇬</h1>
        <p className="text-gray-600 mb-6">30 Methods • 7 Countries • Color Logos Safe</p>
        <div className="bg-gray-50 p-6 rounded-2xl border mb-6">
          <label className="text-sm font-semibold">Amount</label>
          <div className="flex gap-3 mt-2">
            <input type="number" value={amount} onChange={e => setAmount(Number(e.target.value))} className="flex-1 border p-3 rounded-xl text-lg font-bold" />
            <div className="bg-black text-white px-4 py-3 rounded-xl font-mono">{currency} {amount.toLocaleString()}</div>
          </div>
          <input type="range" min={500} max={100000} step={500} value={amount} onChange={e => setAmount(Number(e.target.value))} className="w-full mt-4" />
          <div className="flex flex-wrap gap-2 mt-4">
            {quickAmounts.map(q => (
              <button key={q} onClick={() => setAmount(q)} className={`px-3 py-1 rounded-full border text-sm ${amount===q ? 'bg-black text-white' : 'bg-white'}`}>₦{q.toLocaleString()}</button>
            ))}
          </div>
          <div className="flex gap-2 mt-4">
            {['NGN','GHS','KES','UGX','ZMW','RWF','TZS'].map(c => (
              <button key={c} onClick={() => setCurrency(c)} className={`px-3 py-1 rounded-full text-xs ${currency===c ? 'bg-black text-white' : 'bg-white border'}`}>{c}</button>
            ))}
          </div>
        </div>
        <input placeholder="Search bank or mobile money..." value={search} onChange={e => setSearch(e.target.value)} className="w-full border p-3 rounded-xl mb-4" />
        <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-5 gap-3 mb-8">
          {filtered.map(m => (
            <button key={m.id} onClick={() => setSelectedId(m.id)} className={`p-4 rounded-2xl border text-left ${selectedId===m.id ? 'border-black bg-black text-white' : 'bg-white'}`}>
              <div className="w-12 h-12 rounded-full flex items-center justify-center text-white font-bold text-sm mb-2" style={{backgroundColor: m.color}}>{m.initials}</div>
              <div className="text-sm font-semibold">{m.name}</div>
              <div className="text-xs opacity-70">{(m as any).countryName || 'Nigeria'} • {m.code}</div>
            </button>
          ))}
        </div>
        <div className="bg-black text-white p-6 rounded-2xl">
          <div className="text-3xl font-mono font-bold tracking-wider break-all">{ussd}</div>
          <div className="flex gap-3 mt-6">
            <button onClick={() => navigator.clipboard.writeText(ussd)} className="flex-1 bg-white text-black py-3 rounded-xl font-semibold">Copy Code</button>
            <a href={`tel:${encodeURIComponent(ussd)}`} className="flex-1 bg-green-500 text-white py-3 rounded-xl font-semibold text-center">Dial Now</a>
          </div>
        </div>
      </div>
    </div>
  );
}
