export * from './paystack-ussd';
import { NIGERIAN_BANKS } from './paystack-ussd';
export const ALL_METHODS = [...NIGERIAN_BANKS];
export const TOTAL_COUNT = ALL_METHODS.length;
