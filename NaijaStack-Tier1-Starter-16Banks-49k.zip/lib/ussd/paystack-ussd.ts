export interface USSDMethod {
  id: string; name: string; code: string; country: 'NG'; type: 'bank'; color: string; initials: string;
}
export const NIGERIAN_BANKS: USSDMethod[] = [
  { id: 'access', name: 'Access Bank', code: '*901', color: '#EB7100', initials: 'AB', country: 'NG', type: 'bank' },
  { id: 'gtb', name: 'GTBank', code: '*737', color: '#E85D04', initials: 'GT', country: 'NG', type: 'bank' },
  { id: 'firstbank', name: 'FirstBank', code: '*894', color: '#003366', initials: 'FB', country: 'NG', type: 'bank' },
  { id: 'uba', name: 'UBA', code: '*919', color: '#D00000', initials: 'UB', country: 'NG', type: 'bank' },
  { id: 'zenith', name: 'Zenith Bank', code: '*966', color: '#CC0000', initials: 'ZB', country: 'NG', type: 'bank' },
  { id: 'fidelity', name: 'Fidelity Bank', code: '*770', color: '#00A651', initials: 'FB', country: 'NG', type: 'bank' },
  { id: 'union', name: 'Union Bank', code: '*826', color: '#0072BC', initials: 'UB', country: 'NG', type: 'bank' },
  { id: 'stanbic', name: 'Stanbic IBTC', code: '*909', color: '#004B8D', initials: 'SI', country: 'NG', type: 'bank' },
  { id: 'sterling', name: 'Sterling Bank', code: '*822', color: '#D81B60', initials: 'SB', country: 'NG', type: 'bank' },
  { id: 'wema', name: 'Wema Bank', code: '*945', color: '#7B1FA2', initials: 'WB', country: 'NG', type: 'bank' },
  { id: 'keystone', name: 'Keystone Bank', code: '*7111', color: '#0D47A1', initials: 'KB', country: 'NG', type: 'bank' },
  { id: 'polaris', name: 'Polaris Bank', code: '*833', color: '#4A148C', initials: 'PB', country: 'NG', type: 'bank' },
  { id: 'unity', name: 'Unity Bank', code: '*7799', color: '#00695C', initials: 'UB', country: 'NG', type: 'bank' },
  { id: 'ecobank', name: 'Ecobank', code: '*326', color: '#00838F', initials: 'EB', country: 'NG', type: 'bank' },
  { id: 'fcmb', name: 'FCMB', code: '*329', color: '#FF8F00', initials: 'FB', country: 'NG', type: 'bank' },
  { id: 'jaiz', name: 'Jaiz Bank', code: '*773', color: '#2E7D32', initials: 'JB', country: 'NG', type: 'bank' },
];
export function generatePaystackUSSD(bank: USSDMethod, amount: number, accountNumber: string = '0123456789'): string {
  return `${bank.code}*${Math.round(amount)}*${accountNumber}#`;
}
