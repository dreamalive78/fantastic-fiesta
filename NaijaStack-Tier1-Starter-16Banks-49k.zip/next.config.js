/** @type {import('next').NextConfig} */
const nextConfig = {
  ...(process.env.BUILD_MODE === 'export' && {
    output: 'export',
    distDir: 'out',
    images: { unoptimized: true },
  }),
  typescript: { ignoreBuildErrors: false },
  eslint: { ignoreDuringBuilds: true },
}
module.exports = nextConfig
